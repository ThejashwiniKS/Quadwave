export class Customer
{
    CustomerId:Number=0;
    FirstName:string="";
    LastName:string="";
    CreatedDate:Number=0;
}