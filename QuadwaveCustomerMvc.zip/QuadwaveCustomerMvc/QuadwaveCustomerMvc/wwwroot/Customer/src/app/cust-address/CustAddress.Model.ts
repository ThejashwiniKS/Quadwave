export class CustomerAddress{
    Id:number=0;
    CustomerId:number=0;
    Country:string="";
    City:string="";
    StreetAddress:string="";
    Phone:string="";
}