﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerApi.Dtos
{
    public class AddressUpdateDto
    {
        public int CustomerId { set; get; }
        public string City { set; get; }
        public string StreetAddress { set; get; }
        public string Phone { set; get; }
        public string Country { set; get; }
        //public Customer Customer { set; get; }
    }
}
