﻿using QuadwaveCustomerApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerApi.Data
{
    public class CustomerInfo : ICustomerInfo
    {
        private readonly CustomerDBContext _context;

        public CustomerInfo(CustomerDBContext context)
        {
            _context = context;
        }
        public Customer CreateCustomer(Customer e)
        {
            _context.Customers.Add(e);
            _context.SaveChanges();
            return e;
        }

        public void DeleteCustomer(Customer e)
        {
            _context.Remove(e);
            _context.SaveChanges();
        }

        

        public Customer GetCustomer(int id)
        {
            var application = _context.Customers.SingleOrDefault(m => m.CustomerId == id);
            return application;
        }

        public List<Customer> GetCustomers()
        {
            //var applications = _context.CustomerDetails.Include(c => c.Account).ToList();
            var applications = _context.Customers.ToList();
            return applications;
        }

        public void UpdateCustomer(Customer e)
        {
            _context.SaveChanges();
        }

        
            //THIS IS FOR CUSTOMERADDRESS

        public List<CustomerAddress> GetAddresses()
        {
            var customera = _context.CustomerAddresses.ToList();
            return customera;
        }

        public CustomerAddress CreateAddress(CustomerAddress e)
        {
            _context.CustomerAddresses.Add(e);
            _context.SaveChanges();
            return e;
        }
        public void DeleteAddress(CustomerAddress e)
        {
            _context.Remove(e);
            _context.SaveChanges();
        }

        public CustomerAddress GetAddress(int id)
        {
            var application = _context.CustomerAddresses.SingleOrDefault(m => m.Id == id);
            return application;
        }

        public void UpdateAddress(CustomerAddress e)
        {
            _context.SaveChanges();
        }



    }
}
