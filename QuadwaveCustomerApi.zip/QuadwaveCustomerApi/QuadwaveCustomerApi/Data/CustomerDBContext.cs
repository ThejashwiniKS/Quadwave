﻿using Microsoft.EntityFrameworkCore;
using QuadwaveCustomerApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerApi.Data
{
    public class CustomerDBContext:DbContext
    {
        public CustomerDBContext(DbContextOptions<CustomerDBContext> opt) : base(opt)
        {

        }
        public DbSet<Customer> Customers { set; get; }
        public DbSet<CustomerAddress> CustomerAddresses { set; get; }
    }
}
