﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace QuadwaveCustomerApi.Migrations
{
    public partial class addCustomer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into Customers values('Bhojaraju','H N','1/17/2022 1:53:34')");
            migrationBuilder.Sql("insert into Customers values('Duthi','Shree','1/17/2022 1:55:37')");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
