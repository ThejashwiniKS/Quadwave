﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace QuadwaveCustomerApi.Migrations
{
    public partial class addCustomerAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into CustomerAddresses values(3,'Tumkur','Dibbur','8909988998','India')");
            migrationBuilder.Sql("insert into CustomerAddresses values(4,'Bangalore','Vijayanagar','8987677665','India')");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
